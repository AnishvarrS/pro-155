// Registering component in Target.js

AFRAME.registerComponent("target-fish", {
  init: function () {
    for (var i = 1; i <= 20; i++) {
      //id
      var id = `fish${i}`;

      //position variables     
      var posX =(Math.random() * 3000 + (-1000));      
      var posY = (Math.random() * 2 + (-1));
      var posZ = (Math.random() * 3000 + -1000);

      var position = { x: posX, y: posY, z: posZ };

      //call the function
      this.createfishs(id, position);
    }
  } ,

  createFishs: function(id, position) { 
    
    var oceanEl = document.querySelector("#ocean");

    var fishEl = document.createElement("a-entity");

    fishEl.setAttribute("id",id);
    fishEl.setAttribute("position",position);
    
    fishEl.setAttribute(src="./assets/models/shiny_fish.glb")

    oceanEl.appendChild(fishEl);
  }
});

